/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectkita;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author E R I K
 */
public class Koneksi {
    private static Connection koneksi;

    public static Connection getKoneksi() {
        if (koneksi == null) {
            try {
                // URL koneksi JDBC untuk MySQL
                // db_karaoke adalah nama database yang kita buat
                String url = "jdbc:mysql://localhost:3306/lavienkaraoke_db";
                String user = "root"; // User default XAMPP
                String password = ""; // Password default XAMPP kosong

                // Mendaftarkan driver. Untuk JDBC 4.0+, ini sebenarnya opsional.
                DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());

                // Membuat koneksi
                koneksi = DriverManager.getConnection(url, user, password);
                
                System.out.println("Koneksi ke database berhasil!");

            } catch (SQLException e) {
                // Menampilkan pesan error jika koneksi gagal
                JOptionPane.showMessageDialog(null, "Gagal terkoneksi ke database! Error: " + e.getMessage());
                System.exit(0); // Keluar dari aplikasi jika koneksi gagal
            }
        }
        return koneksi;
    }

    public static void main(String[] args) {
        // Untuk mengetes apakah koneksi berhasil
        Connection testKoneksi = Koneksi.getKoneksi();
        if (testKoneksi != null) {
            JOptionPane.showMessageDialog(null, "Tes koneksi berhasil!");
        }
    }
}
