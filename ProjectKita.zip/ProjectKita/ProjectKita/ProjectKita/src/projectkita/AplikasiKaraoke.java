package projectkita;

/* @author E R I K */ 

public class AplikasiKaraoke {
    
    public static void main (String[] args) {
        
    }
}
